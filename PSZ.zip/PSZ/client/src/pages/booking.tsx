import BookingCalculator from "@/components/booking-calculator";

export default function Booking() {
  return (
    <div className="pt-16 relative z-10">
      <BookingCalculator />
    </div>
  );
}
